## Charla para Meetup Python Madrid

* **Detalles:** https://www.meetup.com/python-madrid/events/266077514/

### Ayúdame a mejorar

Contesta un breve cuestionario sobre la charla para que pueda mejorar como 
ponente, GRACIAS!

https://forms.gle/RkJsYDRTbF5tVNPw8